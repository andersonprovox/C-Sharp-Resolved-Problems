﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace urnaEletronica_0._1
{
    public partial class Form1 : Form
    {
        int bolsomito ;
        int jeremias ;
        int lula ;
        int aecio ;
        int nulo;
        int branco;
        int tmprest;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            
            if (txtDisplay.Text == "70")
            {

                bolsomito += 1;
            }
            else if (txtDisplay.Text == "45")
            {
                aecio += 1;
            }
            else if (txtDisplay.Text == "13")
            {
                lula += 1;
            }
            else if (txtDisplay.Text == "51")
            {
                jeremias += 1;
            }
            else
                nulo += 1;

            txtDisplay.Clear();
        }
        private void btn_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            txtDisplay.Text = txtDisplay.Text + b.Text;
        }

        private void btnCor_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void btnWhite_Click(object sender, EventArgs e)
        {
            branco += 1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (tmprest > 0)
            {
                tmprest = tmprest - 1;
                lblTime.Text = tmprest + "segundos";
            }
            else
            {
                timer1.Stop();
                lblAvisos.Text = "O tempo de votação acabou!!!";
                btnConfirm.Enabled = false;  
            }
        }
    }
}
