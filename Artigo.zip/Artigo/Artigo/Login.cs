﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Artigo
{
    public partial class Login : Form
    {
        public bool logado = false;
        public Conexao conn = null;
        public SqlConnection ConnectOpen = null;

        public Login()
        {
            conn = new Conexao();
            ConnectOpen = conn.ConectarDatabase();
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlCommand = "select * from usuarios where usuario = '" + txtusuario.Text + "' and senha = '" + txtsenha.Text + "'";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand, ConnectOpen);
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                logado = true;
            }
            else
                MessageBox.Show("Usuário e Senha incorreto(s)!");
        }
    }
}
